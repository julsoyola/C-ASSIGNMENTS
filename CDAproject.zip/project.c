
#include "spimcore.h"
#include <stdio.h>
/*
Group members: Juliana Oyola, Cody Davidson, Kevin Estrella, Aidan O'Donnell



Who Does What:
Juls: read_register, readw_memory, PC update
Kevin: ALU, ALUOP, 
Cody: instruction_fetch, instruction_decode, instruction partition
Aidan: Sign_extend, write_register

//debugged by: Cody :D, updated the write_register and addi operations.
*/

/* ALU */
/* 10 Points */
void ALU(unsigned A,unsigned B,char ALUControl,unsigned *ALUresult,char *Zero)
{
 switch((int)ALUControl)
    {
      // A+B
        case 0:
            *ALUresult = A + B;
            break;

        // A-B
        case 1:
            *ALUresult = A - B;
            break;

        // A<B, Z = 1, otherwise Z = 0
        case 2:
            if((signed) A < (signed) B)
                *ALUresult = 1;
            else
                *ALUresult = 0;
            break;

        // A<B, Z = 1, otherwise Z = 0 UNSIGNED
        case 3:
            if(A < B)
                *ALUresult = 1;
            else
                *ALUresult = 0;
            break;

        // A AND B
        case 4:
            *ALUresult = A & B;
            break;

        // A OR B
        case 5:
            *ALUresult = A | B;
            break;

        //Shift left B by 16 bits
        case 6:
            *ALUresult = B << 16;   
            break;

        // NOT A
        case 7:
            *ALUresult = ~A;
            break;
    }
    //if result is zero, and set zero bit
    if(*ALUresult == 0)
        *Zero = 1;
    else
        *Zero = 0;
}

/* instruction fetch */
/* 10 Points */
/*  
    1.Fetch the instruction addressed by PC from Mem and write it to instruction.
    2.Return 1 if a halt condition occurs; otherwise, return 0. 
*/
//Done by Cody Davidson
int instruction_fetch(unsigned PC,unsigned *Mem,unsigned *instruction)
{
   //PC word alignment is not divisible by 4 thus illegal case found, return halt (1).
    if(PC % 4 != 0|| PC > 65536)
    {
      return 1;
    }
    else{
      //FAQ Says to use PC >> 2 to get correct decimal value.
      *instruction = Mem[PC >> 2];
      //using * to set value of actual instruction equivalent to decimal value stored in memory.
    return 0;
    }
    
}
/* instruction partition */
/* 10 Points */
/*
    1. Partition instruction into several parts (op, r1, r2, r3, funct, offset, jsec).
    2. Read line 41 to 47 of spimcore.c for more information.
*/
//Done by Cody Davidson
void instruction_partition(unsigned instruction, unsigned *op, unsigned *r1,unsigned *r2, unsigned *r3, unsigned *funct, unsigned *offset, unsigned *jsec)
{
  //the input is 32 bits, therefore, to attain our desired range - 
  // (31-26), (25-21), etc. we shift the bits of instruction right and & them with their associated partition.
  //values to shift the bits left are found using various instruction formats. Found in module 6 set.

	//r1,	// instruction [25-21]
  unsigned r_Type_partition = 0x1f; //(31)
  *r1 = ((instruction >> 21) & r_Type_partition);
	//r2,	// instruction [20-16]
  *r2 = ((instruction >> 16) & r_Type_partition);
	//r3,	// instruction [15-11]
  *r3 = ((instruction >> 11) & r_Type_partition);
  // op   // instruction [31-26]
  unsigned operation_partition = 0x3f; //(63)
  *op = ((instruction >> 26));
	//funct,	// instruction [5-0]
  *funct = (instruction & operation_partition);
	//offset,	// instruction [15-0]
  unsigned offset_partition = 0xffff;  //(65535)
  *offset = instruction & offset_partition;
	//jsec;	// instruction [25-0]
  unsigned j_partition = 0x3ffffff; //(67108863)
  *jsec = instruction & j_partition;
}



/* instruction decode */
/* 15 Points */
/*
    1. Decode the instruction using the opcode (op).
    2. Assign the values of the control signals to the variables in the structure controls
    (See spimcore.h file).
    The meanings of the values of the control signals:
    For MemRead, MemWrite or RegWrite, the value 1 means that enabled, 0
    means that disabled, 2 means “don’t care”.
    For RegDst, Jump, Branch, MemtoReg or ALUSrc, the value 0 or 1 indicates the
    selected path of the multiplexer; 2 means “don’t care”.
    The following table shows the meaning of the values of ALUOp.

*/
//Done by Cody Davidson
int instruction_decode(unsigned op,struct_controls *controls)
{
  //the opcode is given in 64 bit values, meaning for example an opcode of 001000 converted to decimal is 8, which translates to the "add immediate" operation, 
  switch(op)
  {
    //general r type functions: add, subtract, and, or, set on less than.
    case 0:
    {
      controls->RegDst = 1;
      controls->Jump = 0;
      controls->Branch = 0;
      controls->MemRead = 0;
      controls->MemtoReg = 0;
      //r type instructions will be identified through an aluOP of 7, 111 from binary to decimal is 7.
      controls->ALUOp = 7;
      controls->MemWrite = 0;
      controls->ALUSrc = 0;
      controls->RegWrite = 1;
      break;
    }
    //add immediate
    case 8:
    {
      controls->RegDst = 0;
      controls->Jump = 0;
      controls->Branch = 0;
      controls->MemRead = 0;
      controls->MemtoReg = 0;
      controls->ALUOp = 0;
      controls->MemWrite = 0;
      controls->ALUSrc = 1;
      controls->RegWrite = 1;
      break;
    }
    case 35:
    {
      //load word case.
      controls->RegDst = 0;
      controls->Jump = 0;
      controls->Branch = 0;
      controls->MemRead = 1;
      controls->MemtoReg = 1;
      controls->ALUOp = 0;
      controls->MemWrite = 0;
      controls->ALUSrc = 1;
      controls->RegWrite = 1;
      break;
    }
    case 43:
    {
      //store word.
      //2 indicates dont care values.
      controls->RegDst = 2;
      controls->Jump = 0;
      controls->Branch = 0;
      controls->MemRead = 0;
      controls->MemtoReg = 2;
      controls->ALUOp = 0;        
      controls->MemWrite = 1;
      controls->ALUSrc = 1;
      controls->RegWrite = 0;
      break;
    }
    case 15:
    {
      //load upper immediate
      controls->RegDst = 0;
      controls->Jump = 0;
      controls->Branch = 0;
      controls->MemRead = 0;
      controls->MemtoReg = 0;
      controls->ALUOp = 6;    //alu will shift 16 bits left.
      controls->MemWrite = 0;
      controls->ALUSrc = 1;
      controls->RegWrite = 1;
      break;
    }
    case 4:
    {
      //branch on equal
      controls->RegDst = 2;
      controls->Jump = 0;
      controls->Branch = 1;
      controls->MemRead = 0;
      controls->MemtoReg = 2;
      controls->ALUOp = 1;
      controls->MemWrite = 0;
      controls->ALUSrc = 0;
      controls->RegWrite = 0;
      break;
    }
    case 10:
    {
      //set on less than immediate
      controls->RegDst = 1;
      controls->Jump = 0;
      controls->Branch = 0;
      controls->MemRead = 0;
      controls->MemtoReg = 0;
      controls->ALUOp = 2;
      controls->MemWrite = 0;
      controls->ALUSrc = 0;
      controls->RegWrite = 1;
      break;
    }
    case 11:
    {
      //set on less than immediate unsigned
      controls->RegDst = 1;
      controls->Jump = 0;
      controls->Branch = 0;
      controls->MemRead = 0;
      controls->MemtoReg = 0;
      controls->ALUOp = 3;
      controls->MemWrite = 0;
      controls->ALUSrc = 0;
      controls->RegWrite = 1;
      break;
    }
    case 2:
    {
      //Jump
      controls->RegDst = 0;
      controls->Jump = 1;
      controls->Branch = 0;
      controls->MemRead = 0;
      controls->MemtoReg = 0;
      controls->ALUOp = 0;
      controls->MemWrite = 0;
      controls->ALUSrc = 0;
      controls->RegWrite = 0;
      break;
    }
    
    default:
    {
      //halt case occured, return 1.
      return 1;
    }
  }

  return 0;
}
//Done: Juliana Oyola
void read_register(unsigned r1,unsigned r2,unsigned *Reg,unsigned *data1,unsigned *data2)
{
  /*read the registers given for r1 and r2 from register
  assign the read values to data1 and data2 */
  *data1 = Reg[r1];
  *data2 = Reg[r2];
}


/* Sign Extend */
/* 10 Points */
/*
    1. Assign the sign-extended value of offset to extended_value.
*/
//Done by Aidan O'Donnell
void sign_extend(unsigned offset,unsigned *extended_value)
{
  //Sign bit is the 16th bit, so we have to shift 15 bits to the right
  unsigned signBit = offset >> 15; 

  /*Because we had already set the 16 bit to all zeros in the instruction_partition,
  we only need to account for when the signBit is negative*/
  if (signBit == 1)
  {
    *extended_value = offset | 0xFFFF0000;
  }
  else{
    *extended_value = offset & 0x0000FFFF;
  }
}

/* ALU operations */
/* 10 Points */
/*
    1. Apply ALU operations on data1, and data2 or extended_value (determined by
    ALUSrc).
    2. The operation performed is based on ALUOp and funct.
    3. Apply the function ALU(…).
    4. Output the result to ALUresult.
    5. Return 1 if a halt condition occurs; otherwise, return 0.
*/
int ALU_operations(unsigned data1,unsigned data2,unsigned extended_value,unsigned funct,char ALUOp,char ALUSrc,unsigned *ALUresult,char *Zero)
{
  //Set data2 to extended_value if condition equals 1
	if (ALUSrc == 1) 
  {
		data2 = extended_value;
	}

	// if R-type 
    if (ALUOp == 7) 
    {
    	switch(funct) 
      {
	    	// addition
	    	case 32:
	    		ALUOp = 0;
	    		break;
	    	// subtraction
	    	case 34:
	    		ALUOp = 1;
	    		break;
	    	// set less than operation
	    	case 42:
	    		ALUOp = 2;
	    		break;
	    	//set less than unsigned operation
	    	case 43:
	    		ALUOp = 3;
	    		break;
	    	// AND operation
	    	case 36:
	    		ALUOp = 4;
	    		break;
	    	// OR operation
	    	case 37:
	    		ALUOp = 5;
	    		break;
	    	// shift left right variable
	    	case 4:
	    		ALUOp = 6;
	    		break;
	    	// NOR operation
	    	case 39:
	    		ALUOp = 7;
	    		break;
	    	// halt condition
	    	default:
	    		return 1;
	    }

	    //Call ALU function
	    ALU(data1, data2, ALUOp, ALUresult, Zero);
    }
    else 
    {
    	//Call ALU for non-functions
    	ALU(data1, data2, ALUOp, ALUresult, Zero);
    }

    return 0;
}

/* Read / Write Memory */
/* 10 Points */
//Done: Juliana Oyola
int rw_memory(unsigned ALUresult,unsigned data2,char MemWrite,char MemRead,unsigned *memdata,unsigned *Mem)
{
  //Reads the results into the memdata
  if(MemRead == 1)
  {
    if((ALUresult % 4) == 0)
    {
      //Binary Right Shift Operator
      *memdata = Mem[ALUresult >> 2];
    }
    else
      return 1;
  }
  // stores value of data2 into mem location
  if(MemWrite == 1)
  {
    if((ALUresult % 4) == 0)
    {
      Mem[ALUresult >> 2] = data2;
    }
    else
      return 1;
  }

  //return since no stops happened
  return 0;
}

/* Write Register */
/* 10 Points */
/*
    1. Write the data (ALUresult or memdata) to a register (Reg) addressed by r2 or r3
*/
//Done by Aidan O'Donnell
void write_register(unsigned r2,unsigned r3,unsigned memdata,unsigned ALUresult,char RegWrite,char RegDst,char MemtoReg,unsigned *Reg)
{
  
  if (RegWrite)  //for this function to execute, RegWrite should always be true
  {
    // data from memory (memdata)
		if(MemtoReg && !RegDst)
    {
			Reg[r2] = memdata;
    }
    else if(MemtoReg && RegDst)
    {
			Reg[r3] = memdata;
    }
		else if(!MemtoReg && !RegDst) //data from ALU (aluresult)
    {
			Reg[r2] = ALUresult;
    }
    else if(!MemtoReg && RegDst)
		{
    	Reg[r3] = ALUresult;
    }
  }
}

/* PC update */
/* 10 Points */
/*
    1. Update the program counter (PC).
*/
//Done: Juliana Oyola
void PC_update(unsigned jsec,unsigned extended_value,char Branch,char Jump,char Zero,unsigned *PC)
{
  //updates the counter
  *PC += 4;

  //if we 'branched' and get a 0 then we update the counter
  //we add the extended value
  if(Branch == 1 && Zero == 1)
  { 
    //bitshifted left by two units
    *PC += (extended_value << 2);
  }
  //if we jump, jsec is shifted left by two
  //we use the upper 4 bits of PC then combine them
  if(Jump == 1)
  {
    *PC = (jsec << 2) | (*PC & 0xf0000000);
  }
}

